package ngdemo.domain;

public class NullUser extends User {
}
